jQuery(function($){
	if($.fn.slick){$('.wp-block-catpow-slick').slick();}
});